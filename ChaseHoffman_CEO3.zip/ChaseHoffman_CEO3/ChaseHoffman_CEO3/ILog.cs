﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChaseHoffman_CEO3
{
    public interface ILog
    {
        void Log(string x);
        void LogD(string y);
        void LogW(string z);
        

    }
}
