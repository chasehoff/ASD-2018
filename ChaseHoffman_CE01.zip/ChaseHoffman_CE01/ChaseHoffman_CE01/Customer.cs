﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChaseHoffman_CE01
{
    class Customer
    {
        public CheckingAccount custAcc;
        public string custName;

        public Customer(string cr)
        {
            cr = custName;
            Console.WriteLine($"Thank you for creating an account!");
        }
    }
}
