﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChaseHoffman_CE01
{
    class Menu
    {
        public static void Gui()
        {
 
            Console.WriteLine("[1] Create Customer");
            Console.WriteLine("[2] Create Account");
            Console.WriteLine("[3] Set Account Balance");
            Console.WriteLine("[4]  Display Account Balance");
            Console.WriteLine("");
            Console.WriteLine("[0] Exit");
            Console.WriteLine("Please Type Your Selection...");
        }
    }
}
